package test;

import java.util.ArrayList;
import java.util.Scanner;

public class test {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String input = "";
		int result = 0;
		
		ArrayList<Integer> number = new  ArrayList<Integer>();
		
		System.out.println("###########신나는 덧셈 프로그램###########");
		System.out.print("더하고자하는 숫자를 입력하세요 (종료시 엔터를 입력해 주세요): ");
		
		while(true)
		{
			
			System.out.print("> ");
			input = scan.nextLine();
			if(input.equals(""))
			{
				System.out.print("정말 종료하시겠습니까? y/n : ");
				input = scan.nextLine();
				
				if(input.equals("y"))
				{
					System.out.println("종료합니다!!");
					break;
				}
			}
			
			try{
				number.add(Integer.parseInt(input));
			}catch(NumberFormatException num){
				System.out.println("다시 숫자만 입력해 주세요!!");
				continue;
			}
		}
		
		
		for (Integer integer : number) {
			result += integer;
		}
		
		System.out.println("총 합은 " + result + "입니다");
		
	}
}
